# CleanBrowser for Android

A minimal Android WebView browser designed to hide the status bar, navigation bar, address bar, and search bar. It opens to a clean shortcut page and uses a menu dialog to enter a URL or search terms.

## Build
1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build APK(s)**.
4. Install the generated APK on your POCO X7 Pro.

Package: `com.example.cleanbrowser`

## Notes
- This is source code, not a prebuilt APK.
- Websites may still display their own navigation bars and content; the app hides its own browser controls.
- Immersive full-screen mode can be temporarily revealed by Android system gestures.
- WebView uses Android's installed system WebView component.
- This starter is intentionally minimal and has not been tested on a physical device. Review before daily use.
