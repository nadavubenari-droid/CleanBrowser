# Build CleanBrowser without a PC

This project includes a GitHub Actions workflow that builds the APK on GitHub's cloud computers. You still need a free GitHub account and to upload this project once; no computer is required.

1. In your phone browser, open https://github.com/new and create a repository (for example, `CleanBrowser`). You can keep it private.
2. Open the new repository and use **Add file → Upload files**. Extract this ZIP on your phone first, then upload the contents of the `CleanBrowser` folder, including the hidden `.github` folder and its workflow file. If your file manager hides dot-folders, enable “show hidden files”.
3. Commit the uploaded files.
4. In the repository, open **Actions** → **Build CleanBrowser APK** → **Run workflow**.
5. Wait for the workflow to finish successfully. Open the completed run and download the `CleanBrowser-debug-apk` artifact.
6. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` to install it. If Android asks, allow your browser or file manager to install unknown apps.

The APK is a debug build, not a Play Store release. Keep the repository private if you don't want to publish the source code. GitHub's interface may vary slightly on mobile.
