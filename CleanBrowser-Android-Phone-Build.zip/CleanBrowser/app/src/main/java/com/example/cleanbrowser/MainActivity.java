package com.example.cleanbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout root, header;
    private WebView web;
    private boolean showingHome = true;
    private SharedPreferences prefs;
    private final int bg = Color.rgb(8, 29, 45);
    private final int accent = Color.rgb(57, 173, 123);
    private final List<String[]> defaults = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("cleanbrowser", MODE_PRIVATE);
        defaults.add(new String[]{"YouTube", "https://m.youtube.com"});
        defaults.add(new String[]{"Wikipedia", "https://www.wikipedia.org"});
        defaults.add(new String[]{"Reddit", "https://www.reddit.com"});
        defaults.add(new String[]{"GitHub", "https://github.com"});
        defaults.add(new String[]{"Google", "https://www.google.com"});
        enterImmersive();
        buildShell();
        showHome();
    }

    private void enterImmersive() {
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        setContentView(root);
        header = new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(22, 20, 18, 12);
        TextView leaf = text("◈", 34, accent); leaf.setTypeface(null, Typeface.BOLD);
        header.addView(leaf, new LinearLayout.LayoutParams(48, 52));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("CleanBrowser", 21, Color.WHITE); title.setTypeface(null, Typeface.BOLD);
        brand.addView(title); brand.addView(text("Browse without distractions", 13, 0xFFB9CAD6));
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        Button menu = new Button(this); menu.setText("⋮"); menu.setTextSize(24); menu.setTextColor(Color.WHITE);
        menu.setBackgroundColor(Color.TRANSPARENT); menu.setOnClickListener(v -> showMenu());
        header.addView(menu, new LinearLayout.LayoutParams(48, 48)); root.addView(header);
        web = new WebView(this); web.setBackgroundColor(Color.WHITE);
        web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setSupportZoom(true); web.getSettings().setBuiltInZoomControls(true); web.getSettings().setDisplayZoomControls(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override public void onPageFinished(WebView view, String url) { showingHome = false; }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void showHome() {
        showingHome = true;
        while (root.getChildCount() > 1) root.removeViewAt(1);
        web.loadDataWithBaseURL(null, "<html><body style='margin:0;background:#081d2d;color:white;font-family:sans-serif;'><div style='padding:38px 22px 20px;text-align:center;'><div style='font-size:34px;line-height:1.2;'>A simpler way<br>to browse</div><p style='color:#b9cad6;font-size:16px;line-height:1.5;margin-top:18px;'>No search bar. No address bar.<br>Just the web.</p></div></body></html>", "text/html", "UTF-8", null);
        // Keep shortcuts as native controls below the welcome page.
        root.removeView(web);
        ScrollView scroll = new ScrollView(this); LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(20, 18, 20, 28); page.setBackgroundColor(bg);
        TextView hero = text("A simpler way\nto browse", 34, Color.WHITE); hero.setGravity(Gravity.CENTER); hero.setLineSpacing(5, 1); hero.setPadding(0, 25, 0, 0); page.addView(hero);
        TextView sub = text("No search bar. No address bar.\nJust the web.", 16, 0xFFB9CAD6); sub.setGravity(Gravity.CENTER); sub.setPadding(0, 18, 0, 28); page.addView(sub);
        LinearLayout row = null; int count = 0;
        for (String[] item : defaults) {
            if (count % 3 == 0) { row = new LinearLayout(this); row.setGravity(Gravity.CENTER); row.setPadding(0, 4, 0, 4); page.addView(row); }
            Button b = new Button(this); b.setText(item[0]); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(13); b.setBackground(shape(0xFF18384E, 24));
            final String url = item[1]; b.setOnClickListener(v -> loadUrl(url));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 82, 1); lp.setMargins(5, 5, 5, 5); row.addView(b, lp); count++;
        }
        Button add = new Button(this); add.setText("＋  Add website"); add.setAllCaps(false); add.setTextColor(Color.WHITE); add.setBackground(shape(0xFF18384E, 24)); add.setOnClickListener(v -> promptUrl());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, 54); ap.setMargins(5, 20, 5, 0); page.addView(add, ap);
        TextView note = text("Open the menu to visit a URL, go back, or return home.", 12, 0xFF91A9B9); note.setGravity(Gravity.CENTER); note.setPadding(0, 20, 0, 0); page.addView(note);
        scroll.addView(page); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void loadUrl(String raw) {
        if (raw == null) return;
        String url = raw.trim(); if (url.isEmpty()) return;
        if (!url.matches("(?i)^https?://.*")) {
            if (url.contains(".") && !url.contains(" ")) url = "https://" + url;
            else { try { url = "https://www.google.com/search?q=" + URLEncoder.encode(url, "UTF-8"); } catch (Exception ignored) {} }
        }
        root.removeView(web);
        // Remove the home scroll view if present; preserve header.
        if (root.getChildCount() > 1) root.removeViewAt(1);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        showingHome = false; web.loadUrl(url);
    }

    private void promptUrl() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("example.com or search terms"); input.setTextColor(Color.WHITE); input.setHintTextColor(0xFF9FB1BF);
        input.setPadding(22, 10, 22, 10); input.setBackground(shape(0xFF18384E, 18));
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(22, 8, 22, 0); wrap.addView(input);
        new AlertDialog.Builder(this).setTitle("Visit a website").setView(wrap).setNegativeButton("Cancel", null).setPositiveButton("Go", (d, w) -> loadUrl(input.getText().toString())).show();
    }
    private void showMenu() {
        String[] actions = showingHome ? new String[]{"Visit a website", "Home", "Clear browsing data", "About CleanBrowser"} : new String[]{"Visit a website", "Back", "Home", "Reload", "Clear browsing data", "About CleanBrowser"};
        new AlertDialog.Builder(this).setTitle("CleanBrowser").setItems(actions, (dialog, which) -> {
            String a = actions[which];
            if (a.equals("Visit a website")) promptUrl();
            else if (a.equals("Back")) { if (web.canGoBack()) web.goBack(); else showHome(); }
            else if (a.equals("Home")) showHome();
            else if (a.equals("Reload")) web.reload();
            else if (a.equals("Clear browsing data")) new AlertDialog.Builder(this).setMessage("Clear cookies, cached files, and browsing history on this device?").setNegativeButton("Cancel", null).setPositiveButton("Clear", (d2,w2) -> { web.clearHistory(); web.clearCache(true); android.webkit.CookieManager.getInstance().removeAllCookies(null); android.webkit.CookieManager.getInstance().flush(); }).show();
            else if (a.equals("About CleanBrowser")) new AlertDialog.Builder(this).setTitle("CleanBrowser").setMessage("A minimal full-screen browser with no visible address or search bar. Use the menu to enter a website address.").setPositiveButton("OK", null).show();
        }).show();
    }
    @Override public void onBackPressed() { if (!showingHome && web.canGoBack()) web.goBack(); else if (!showingHome) showHome(); else super.onBackPressed(); }
}
